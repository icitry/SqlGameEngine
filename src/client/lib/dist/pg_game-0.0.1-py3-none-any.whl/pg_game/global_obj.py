from typing import Optional

from .postgres_config import PGConfig

env_state = None

pg_config: Optional[PGConfig] = None
